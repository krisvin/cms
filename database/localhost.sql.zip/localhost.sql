-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 24, 2013 at 04:25 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `comp_ms`
--
CREATE DATABASE `comp_ms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `comp_ms`;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `b_id` int(4) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(250) NOT NULL,
  `cat_id` int(4) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`b_id`, `b_name`, `cat_id`) VALUES
(17, 'Sony', 9),
(16, 'Samsung', 8),
(15, 'Onida', 7),
(14, 'HP', 6),
(13, 'Dell', 5),
(12, 'Sony', 4),
(11, 'Nokia', 4);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(30) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(4, 'Phone'),
(5, 'Laptop'),
(6, 'Printer'),
(7, 'TV'),
(8, 'DVD Player'),
(9, 'Camera');

-- --------------------------------------------------------

--
-- Table structure for table `co_report`
--

CREATE TABLE IF NOT EXISTS `co_report` (
  `r_id` int(5) NOT NULL AUTO_INCREMENT,
  `re_from` varchar(20) NOT NULL,
  `re_to` varchar(20) NOT NULL,
  `re_title` longtext NOT NULL,
  `report_msg` longtext NOT NULL,
  `co_id` int(5) NOT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `co_report`
--

INSERT INTO `co_report` (`r_id`, `re_from`, `re_to`, `re_title`, `report_msg`, `co_id`) VALUES
(36, 'vinu', 'Diya', 'reply :Java applications not working.', 'Solve the complaint as fast as possible', 33),
(37, 'diya', 'vinu', 'Completed', 'The problem solved...', 33),
(38, 'admin', 'manu', 'reply :Java applications not working.', 'Problem Solved. Thanks for using CMS...', 33),
(39, 'mohan', 'lavanya', 'Complaint Solved', 'Ref:3455G54677', 37),
(40, 'vinu', 'Diya', 'reply :Java applications not working.', 'Perfect...', 33);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `co_id` int(4) NOT NULL AUTO_INCREMENT,
  `c_from` varchar(150) NOT NULL,
  `to` varchar(150) NOT NULL,
  `cat_id` int(4) NOT NULL,
  `b_id` int(4) NOT NULL,
  `p_id` int(4) NOT NULL,
  `title` varchar(250) NOT NULL,
  `desc` longtext NOT NULL,
  `c_date` date NOT NULL,
  `solv_mgr` int(4) NOT NULL,
  `solv_ex` int(4) NOT NULL,
  `solv_dat` date NOT NULL,
  `check_date` date NOT NULL,
  `c_status` varchar(20) NOT NULL,
  PRIMARY KEY (`co_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`co_id`, `c_from`, `to`, `cat_id`, `b_id`, `p_id`, `title`, `desc`, `c_date`, `solv_mgr`, `solv_ex`, `solv_dat`, `check_date`, `c_status`) VALUES
(36, 'manu', 'admin', 8, 16, 19, 'No disk', 'After inserting the disk, my DVD Player shows a message: No Disk!', '2013-03-16', 11, 10, '2013-03-26', '0000-00-00', 'ex_complet'),
(35, 'sinu', 'admin', 9, 17, 20, 'Lens error', 'My camera showing lens error', '2013-03-16', 10, 0, '2013-03-26', '0000-00-00', '0'),
(34, 'gopika', 'admin', 7, 15, 18, 'No signal', 'Showing a message No Signal! after connecting HDMI cable.', '2013-03-16', 0, 0, '2013-03-26', '0000-00-00', '0'),
(33, 'manu', 'admin', 4, 11, 14, 'Java applications not working.', 'Some java applications not working in my phone...', '2013-03-13', 8, 7, '2013-03-23', '2013-03-13', 're_send'),
(37, 'meera', 'admin', 5, 13, 16, 'Not working', 'After showing the welcome page, the system restartig automatically.', '2013-03-16', 9, 9, '2013-03-26', '2013-03-16', 'mgr_check');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `f_id` int(5) NOT NULL AUTO_INCREMENT,
  `send_from` varchar(30) NOT NULL,
  `send_to` varchar(30) NOT NULL,
  `sub` longtext NOT NULL,
  `desc` longtext NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `user` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `user`, `status`) VALUES
(1, 'admin', 'admin', 'admin', '1'),
(24, 'vinu', 'vinu', 'service manager', '1'),
(25, 'diya', 'diya', 'service executive', '1'),
(26, 'manu', 'manu', 'user', '1'),
(27, 'gopika', 'gopika', 'user', '1'),
(28, 'madhu', 'madhu', 'service executive', '1'),
(29, 'lavanya', 'lavanya', 'service manager', '1'),
(30, 'sinu', 'sinu', 'user', '1'),
(31, 'meera', 'meera', 'user', '1'),
(32, 'mohan', 'mohan', 'service executive', '1'),
(33, 'unni', 'unni', 'service manager', '1'),
(34, 'babu', 'babu', 'service manager', '1'),
(35, 'shan', 'shan', 'service executive', '1');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(4) NOT NULL AUTO_INCREMENT,
  `p_na` varchar(20) NOT NULL,
  `b_id` int(4) NOT NULL,
  `cat_id` int(4) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_na`, `b_id`, `cat_id`) VALUES
(20, 'SDC172', 17, 9),
(19, 'S546', 16, 8),
(18, 'Black', 15, 7),
(17, 'H177', 14, 6),
(16, 'D70', 13, 5),
(14, '2730 classic', 11, 4);

-- --------------------------------------------------------

--
-- Table structure for table `service_exec`
--

CREATE TABLE IF NOT EXISTS `service_exec` (
  `ex_id` int(4) NOT NULL AUTO_INCREMENT,
  `ex_na` varchar(20) NOT NULL,
  `ex_g` varchar(7) NOT NULL,
  `ex_add` varchar(150) NOT NULL,
  `ex_phn` varchar(20) NOT NULL,
  `ex_mail` varchar(30) NOT NULL,
  `ex_una` varchar(30) NOT NULL,
  `ex_pwd` varchar(30) NOT NULL,
  `mgr_id` int(5) NOT NULL,
  `ex_sta` varchar(7) NOT NULL,
  PRIMARY KEY (`ex_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `service_exec`
--

INSERT INTO `service_exec` (`ex_id`, `ex_na`, `ex_g`, `ex_add`, `ex_phn`, `ex_mail`, `ex_una`, `ex_pwd`, `mgr_id`, `ex_sta`) VALUES
(9, 'Mohan', 'male', 'M Villa\r\nKollam', '9446752214', 'mohan@gmail.com', 'mohan', 'mohan', 9, '1'),
(8, 'Madhu', 'male', 'Madhu Bhavan\r\nKollam', '9895475566', 'madhu@gmail.com', 'madhu', 'madhu', 10, '1'),
(7, 'Diya', 'male', 'Kollam', '9894123458', 'diya@gmail.com', 'diya', 'diya', 8, '1'),
(10, 'Shan', 'male', 'Shan Manzil', '9855647521', 'shan@gmail.com', 'shan', 'shan', 11, '1');

-- --------------------------------------------------------

--
-- Table structure for table `service_mgr`
--

CREATE TABLE IF NOT EXISTS `service_mgr` (
  `mgr_id` int(4) NOT NULL AUTO_INCREMENT,
  `mgr_name` varchar(20) NOT NULL,
  `mgr_gender` varchar(7) NOT NULL,
  `mgr_add` text NOT NULL,
  `mgr_phone` varchar(20) NOT NULL,
  `mgr_email` varchar(30) NOT NULL,
  `mgr_una` varchar(30) NOT NULL,
  `mgr_pwd` varchar(30) NOT NULL,
  `cat_id` int(5) NOT NULL,
  `mgr_sta` varchar(5) NOT NULL,
  PRIMARY KEY (`mgr_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `service_mgr`
--

INSERT INTO `service_mgr` (`mgr_id`, `mgr_name`, `mgr_gender`, `mgr_add`, `mgr_phone`, `mgr_email`, `mgr_una`, `mgr_pwd`, `cat_id`, `mgr_sta`) VALUES
(9, 'Lavanya', 'female', 'Rose Villa\r\nKollam', '8129658749', 'lavanya@gmail.com', 'lavanya', 'lavanya', 5, '1'),
(8, 'Vinayak', 'male', 'Kala\r\nMalapperoor', '9633914696', 'vinayakayoor@gmail.com', 'vinu', 'vinu', 4, '1'),
(10, 'Unni', 'male', 'Nest\r\nKollam', '9447856624', 'unni@gmail.com', 'unni', 'unni', 9, '1'),
(11, 'Babu', 'male', 'BB Villa', '9854775566', 'babu@gmail.com', 'babu', 'babu', 8, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE IF NOT EXISTS `user_reg` (
  `u_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `address` varchar(150) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `district` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `una` varchar(30) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `u_status` varchar(5) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`u_id`, `name`, `address`, `gender`, `district`, `state`, `phone`, `mail`, `una`, `pwd`, `u_status`) VALUES
(4, 'Manu', 'Kollam', 'male', 'Kollam', 'Kerala', '9998547562', 'manu@gmail.com', 'manu', 'manu', '1'),
(5, 'Gopika', 'G P Bhavan\r\nKollam', 'female', 'Kottayam', 'Kerala', '8124557788', 'gopika@gmail.com', 'gopika', 'gopika', '1'),
(6, 'Sinu', 'Sinu Bhavan\r\nKollam', 'male', 'Kollam', 'Kerala', '9992455778', 'sinu@gmail.com', 'sinu', 'sinu', '1'),
(7, 'Meera', 'MS Villa\r\nKottayam', 'female', 'Kottayam', 'Kerala', '9895447755', 'meera@gmail.com', 'meera', 'meera', '1');
